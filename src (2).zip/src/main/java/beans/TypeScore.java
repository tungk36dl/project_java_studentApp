package beans;

public enum TypeScore {
    attendance, test, final_exam
}
