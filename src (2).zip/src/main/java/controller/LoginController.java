package controller;

import java.io.InputStream;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import beans.User;
import dao.DaoUser;
import requests.AccountReq;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.bind.annotation.RequestParam;
@Controller
public class LoginController {

    @Autowired
    private DaoUser daoUser;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();


	@GetMapping("/login")
	public String showLoginForm() {
	    return "authentication/login";
	}
	
	@PostMapping("/login")
	public String processLogin(
	        @RequestParam("username") String username,
	        @RequestParam("password") String password,
	        HttpSession session,
	        Model model) {
	
	    User user = daoUser.findByUsername(username);
	    if (user != null && passwordEncoder.matches(password, user.getPassword())) {
	        session.setAttribute("loggedInUser", user);
	        return "redirect:/home"; // Trang chính sau khi login
	    } else {
	        model.addAttribute("error", "Sai tài khoản hoặc mật khẩu");
	        return "test";
	    }
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
	    session.invalidate();
	    return "redirect:/login";
	}
    

    
    @GetMapping("/register")
    public String Register(Model model) {
    	model.addAttribute("accountReq", new AccountReq());
    	return "authentication/register";
    }

  
}
