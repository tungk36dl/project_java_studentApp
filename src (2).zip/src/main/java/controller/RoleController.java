package controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import beans.Role;
import dao.DaoRole;
import utils.IdUtil;

@Controller
public class RoleController {
	@Autowired
    DaoRole daoRole;

    @GetMapping("/roles")
    public String redirectToRoleView() {
        return "redirect:/role_view";
    }

    @GetMapping("/roles/role_create_form")
    public String showForm(Model model) {
        model.addAttribute("role", new beans.Role());
        return "roles/role_create_form";
    }

    @PostMapping(value="/roles/save")
    public String save(@ModelAttribute("role") Role role, BindingResult result) {
        System.out.println("Dữ liệu sản phẩm: " + role);
        role.setId(IdUtil.generateId()); // 🛠️ Thêm dòng này để đảm bảo có ID
        role.setCreatedDate(new Date());
        role.setUpdatedDate(new Date());
        daoRole.save(role);
        return "redirect:/roles/role_view";
    }

    @RequestMapping("/roles/role_view")
    public String viewRoles(Model model) {
        List<Role> list = daoRole.getRole();
        model.addAttribute("list", list);
        return "roles/role_view";
    }

    @RequestMapping(value = "/roles/editrole/{id}")
    public String edit(@PathVariable String id, Model model) {
        Role role = daoRole.getRoleById(id);
        model.addAttribute("role", role);
        return "roles/role_edit_form";
    }

    @RequestMapping(value = "/roles/editsave", method = RequestMethod.POST)
    public String editSave(@ModelAttribute("role") Role role, BindingResult result) {
        if (result.hasErrors()) {
            System.out.println("Có lỗi trong dữ liệu: " + result.getAllErrors());
            return "role_edit_form";
        }
        role.setUpdatedDate(new	Date());
        
        daoRole.update(role);
        return "redirect:/roles/role_view";
    }

    @RequestMapping(value = "/roles/deleterole/{id}", method = RequestMethod.GET)
    public String delete(@PathVariable String id) {
        daoRole.delete(id);
        return "redirect:/roles/role_view";
    }
}
