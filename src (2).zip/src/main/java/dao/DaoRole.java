package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import beans.Role;

public class DaoRole {
	private JdbcTemplate template;

    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }
    public int save(Role p) {
        String sql = "INSERT INTO Role (id, name, status, createdDate, updatedDate) VALUES (?, ?, ?, ?, ?)";
        return template.update(sql, p.getId(), p.getName(), p.isStatus(), p.getCreatedDate(), p.getUpdatedDate());
    }

    public int update(Role p) {
        String sql = "UPDATE Role SET name = ?, status = ?, updatedDate = ? WHERE id = ?";
        return template.update(sql, p.getName(), p.isStatus(), p.getUpdatedDate(), p.getId());
    }

    public int delete(String id) {
        String sql = "DELETE FROM Role WHERE id = ?";
        return template.update(sql, id);
    }

    public Role getRoleById(String id) {
        String sql = "SELECT * FROM Role WHERE id = ?";
        return template.queryForObject(sql, new Object[] { id }, new BeanPropertyRowMapper<>(Role.class));
    }
      
    public List<Role> getRole() {
        String sql = "SELECT * FROM Role";
        return template.query(sql, new RowMapper<Role>() {
            @Override
            public Role mapRow(ResultSet rs, int rowNum) throws SQLException {
                Role role = new Role();
                role.setId(rs.getString("id"));
                role.setName(rs.getString("name"));
                role.setStatus(rs.getBoolean("status"));
                role.setCreatedDate(rs.getDate("createdDate"));
                role.setUpdatedDate(rs.getDate("updatedDate"));
                return role;
            }
        });
    }

    
}
