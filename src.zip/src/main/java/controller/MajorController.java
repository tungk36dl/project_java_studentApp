//package controller;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.validation.BindingResult;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//
//import beans.Major;
//import dao.DaoMajor;
//
//
//@Controller
//public class MajorController {
//	
//    @Autowired
//	 private DaoMajor daoMajor;
//
////	    @GetMapping("/major/")
////	    public String redirectToMajorView() {
////	        return "redirect:/major_view";
////	    }
//
//	    @GetMapping("/major/major_create_form")
//	    public String showForm(Model model) {
//	        model.addAttribute("product", new Major());
//	        return "product_create_form";
//	    }
//
//	    @PostMapping("/major/major_save")
//	    public String save(@ModelAttribute("product") Major prd, BindingResult result) {
//	        if (result.hasErrors()) {
//	            return "major_create_form";
//	        }
//	        System.out.println("Dữ liệu sản phẩm: " + prd);
//	        daoMajor.save(prd);
//	        return "redirect:/major_view";
//	    }
//
//	    @GetMapping("/major/major_view")
//	    public String viewMajor(Model model) {
//	        List<Major> list = daoMajor.getMajor();
//	        model.addAttribute("list", list);
//	        return "admin/major/major_view";
//	    }
//
//	    @GetMapping("/major/editmajor/{id}")
//	    public String edit(@PathVariable String id, Model model) {
//	        Major major = daoMajor.getMajorById(id);
//	        model.addAttribute("product", major);
//	        return "major_edit_form";
//	    }
//
//	    @PostMapping("/major/editsave")
//	    public String editSave(@ModelAttribute("major")Major  major, BindingResult result) {
//	        if (result.hasErrors()) {
//	            System.out.println("Có lỗi trong dữ liệu: " + result.getAllErrors());
//	            return "major_edit_form";
//	        }
//	        daoMajor.update(major);
//	        return "redirect:/major_view";
//	    }
//
//	    @GetMapping("/major/deletemajor/{id}")
//	    public String delete(@PathVariable String id) {
//	        daoMajor.delete(id);
//	        return "redirect:/major_view";
//	    }
//}
