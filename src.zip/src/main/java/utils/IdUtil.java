package utils;

public class IdUtil {
	 public static String generateId() {
	    	return String.valueOf(System.currentTimeMillis());
	    	}
}