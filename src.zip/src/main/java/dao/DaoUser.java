package dao;

public class DaoUser {

}
