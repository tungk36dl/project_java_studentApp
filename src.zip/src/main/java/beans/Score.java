package beans;

public class Score {
    private int id;
    private int studentId;
    private int subjectDetailId;
    private float score10;
    private String letterGrade;
    private float gpa4;

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }

    public int getSubjectDetailId() { return subjectDetailId; }
    public void setSubjectDetailId(int subjectDetailId) { this.subjectDetailId = subjectDetailId; }

    public float getScore10() { return score10; }
    public void setScore10(float score10) { this.score10 = score10; }

    public String getLetterGrade() { return letterGrade; }
    public void setLetterGrade(String letterGrade) { this.letterGrade = letterGrade; }

    public float getGpa4() { return gpa4; }
    public void setGpa4(float gpa4) { this.gpa4 = gpa4; }
}
