package beans;

public class ScoreComponent {
    private int id;
    private int scoreId;
    private TypeScore typeScore;
    private float score;
    private float weight;

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getScoreId() { return scoreId; }
    public void setScoreId(int scoreId) { this.scoreId = scoreId; }

    public TypeScore getTypeScore() { return typeScore; }
    public void setTypeScore(TypeScore typeScore) { this.typeScore = typeScore; }

    public float getScore() { return score; }
    public void setScore(float score) { this.score = score; }

    public float getWeight() { return weight; }
    public void setWeight(float weight) { this.weight = weight; }
}
