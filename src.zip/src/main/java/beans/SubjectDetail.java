package beans;

public class SubjectDetail {
    private int id;
    private int teacherId;
    private int subjectId;
    private Semester semester;
    private int classId;

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getTeacherId() { return teacherId; }
    public void setTeacherId(int teacherId) { this.teacherId = teacherId; }

    public int getSubjectId() { return subjectId; }
    public void setSubjectId(int subjectId) { this.subjectId = subjectId; }

    public Semester getSemester() { return semester; }
    public void setSemester(Semester semester) { this.semester = semester; }

    public int getClassId() { return classId; }
    public void setClassId(int classId) { this.classId = classId; }
}
