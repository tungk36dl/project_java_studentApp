package requests;

public class InputScoreReq {
	
}
