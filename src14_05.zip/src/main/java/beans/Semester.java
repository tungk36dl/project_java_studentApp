package beans;

public enum Semester {
    semester1, semester2, semester3,
    semester4, semester5, semester6,
    semester7, semester8, semester9
}
